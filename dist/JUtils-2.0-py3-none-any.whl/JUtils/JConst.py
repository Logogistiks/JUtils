"""Constants for keeping code clean"""

NL = '\n' #newline constant to keep code clean

INF = float("inf")